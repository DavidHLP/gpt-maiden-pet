GPT娘 refined pet package
Compatible v2:1536x2288 RGBA PNG;8x11 grid;192x208 cells.
Original Stacky package is preserved. This package is a separate refined version.
Nine fixed-frame state animations and sixteen gaze directions.
Some intermediate gaze angles are deliberately subtle at native size.
No frame interpolation or crossfade is used in the pet.
Artwork generated from supplied references; Blender provides editable timeline preview, not a rigged3D model.
